import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import admin from 'firebase-admin';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import Contact from './models/Contact.js';
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());
if(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64){
  const serviceAccount = JSON.parse(Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64, 'base64').toString('utf8'));
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
} else {
  console.warn('No Firebase service account provided - backend will not write to Firestore in production.');
}
if(process.env.MONGODB_URI){
  mongoose.connect(process.env.MONGODB_URI).then(()=> console.log('MongoDB connected')).catch(err=> console.log('MongoDB connection failed', err));
}
app.post('/api/contact', async (req,res)=> {
  try{
    const { name, email, message } = req.body;
    if(process.env.MONGODB_URI){
      await Contact.create({ name, email, message });
    }
    res.json({ success:true });
  }catch(e){ console.error(e); res.status(500).json({ error:'failed' }); }
});
app.get('/', (req,res)=> res.send('NextGen backend running'));
const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log('Server started on '+PORT));
