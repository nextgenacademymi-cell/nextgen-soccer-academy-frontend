NextGen Soccer Academy - Click-to-Deploy Starter

Front end: /frontend  (React + Vite + Tailwind)
Back end: /backend   (Express + Firebase Admin + optional MongoDB)

Scheduler default hours:
- Mon-Fri 4-7pm
- Sat 10am-6pm

Deploy:
- Frontend: Vercel > import repo > root: frontend. Set VITE_* envs.
- Backend: Render > new web service > root: backend. Set FIREBASE_SERVICE_ACCOUNT_BASE64, MONGODB_URI (optional), ADMIN_EMAIL, CLIENT_URL.

